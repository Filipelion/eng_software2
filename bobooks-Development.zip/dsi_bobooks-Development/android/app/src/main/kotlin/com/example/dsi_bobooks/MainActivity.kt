package com.example.dsi_bobooks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
