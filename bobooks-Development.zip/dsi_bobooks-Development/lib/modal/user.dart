class FBUser {
  String userId;
  FBUser({this.userId});
}
